the fight file contains our Gokemon sprite sheets, type effect sprite sheets, save game file, and fight page background.
Overworld file contains all our maps, their relevant txt file that stores the collision locations and the sprites for our player and NPC.
Text file contains the dialogue used to tell the story.
Fight.py is our code to run the fighting.
pokemon_game-new_with_start_page.py is our main game code that you need to open to run the game.
vector.py contains the vectors.
Welcome.py is our welcome screen code.
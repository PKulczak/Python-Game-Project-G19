try:
    import simplegui
except ImportError:
    import SimpleGUICS2Pygame.simpleguics2pygame as simplegui
import random
import os
from vector import Vector
from Welcome import Welcome
from fight import Pokemon
from fight import Fight
from fight import Kbd

WIDTH = 800
HEIGHT = 480

walls_list = []
npc_list = []
npc_lost = []

class Clock:
    def __init__(self):
        self.time = 0
        
    def tick(self):
        self.time += 1
    
    def transition(self,frame_duration):
        if self.time >= frame_duration:
            self.time = 0
            return True
        else:
            return False

class Keyboard:
    def __init__(self):
        self.right = False
        self.left = False
        self.up = False
        self.down = False
        self.pokedex = False
        self.start = False
        self.tutorial = False
        self.back = False

    def keyDown(self, key):
        if key == simplegui.KEY_MAP['right']:
            self.right = True
        if key == simplegui.KEY_MAP['left']:
            self.left = True
        if key == simplegui.KEY_MAP['up']:
            self.up = True
        if key == simplegui.KEY_MAP['down']:
            self.down = True
        if key == simplegui.KEY_MAP['space']:
            self.start = True
        if key == simplegui.KEY_MAP['p']:
            self.pokedex = True
        if key == simplegui.KEY_MAP['q']:
            self.back = True
        if key == simplegui.KEY_MAP['t']:
            self.tutorial = True


    def keyUp(self, key):
        if key == simplegui.KEY_MAP['right']:
            self.right = False
        if key == simplegui.KEY_MAP['left']:
            self.left = False
        if key == simplegui.KEY_MAP['up']:
            self.up = False
        if key == simplegui.KEY_MAP['down']:
            self.down = False

    def KeyReset(self):
        self.right = False
        self.left = False
        self.up = False
        self.down = False
        
class Player:
    def __init__(self, clock): 
        self.clock = clock
        self.image = simplegui._load_local_image('{}/Overworld/Other/player.png'.format(os.getcwd()))
        self.rows = 4
        self.columns = 4
        
        width = self.image.get_width()
        frame_width = width//self.columns
        height = self.image.get_height()
        frame_height = height//self.rows

        self.pos = Vector(552, 224)
        self.frame_center = [frame_width/2, frame_height/2]
        self.frame_dim = [frame_width, frame_height]
        self.frame_index = [0,0]
        
        self.vel = Vector(0,0)
        self.moving = False
        self.in_fight = False
        self.interacting = False
        self.lock = False
        self.scale_factor = 0.26
        
        self.lives = 6
        self.heart_img = simplegui._load_local_image('{}/Overworld/Other/heart.png'.format(os.getcwd()))

        self.player_left = self.pos.x - self.frame_center[0]
        self.player_right = self.pos.x + self.frame_center[0]
        self.player_top = self.pos.y
        self.player_bot = self.pos.y + self.frame_center[1]
        
        self.pokemon_list = []
        with open('{}/Fight/PlayerPokemon.txt'.format(os.getcwd()),"r") as file:
            party = file.readlines()
            for pokemonL in party:
                pokemonL = pokemonL.split()
                pokemon = Pokemon(pokemonL[0], int(pokemonL[1]), int(pokemonL[2]), int(pokemonL[3]), [210, 250], [570, 140])
                self.pokemon_list.append(pokemon)
            file.close()

    def draw(self, canvas):
        if self.moving == True:
            canvas.draw_image(self.image, 
                    [self.frame_center[0] + self.frame_index[0] * self.frame_dim[0], 
                     self.frame_center[1] + self.frame_index[1] * self.frame_dim[1]], 
                     self.frame_dim, [self.pos.x,self.pos.y], [self.frame_dim[0]*self.scale_factor,self.frame_dim[1]*self.scale_factor])
        else:
            canvas.draw_image(self.image, 
                    [self.frame_center[0] + 0 * self.frame_dim[0], 
                     self.frame_center[1] + self.frame_index[1] * self.frame_dim[1]], 
                     self.frame_dim, [self.pos.x,self.pos.y], [self.frame_dim[0]*self.scale_factor,self.frame_dim[1]*self.scale_factor])

        canvas.draw_image(self.heart_img, [8,8], [16,16], [16,16], [16,16])
        lives = "x"+str(self.lives)
        canvas.draw_text(lives, [32,20], 24, "Black")
        
        self.clock.tick()
        move_on = self.clock.transition(6)
        if move_on == True:
            self.next_frame()
        
    def next_frame(self):
        self.frame_index[0] += 1
        if self.frame_index[0] >= self.columns:
            self.frame_index[0] = 0

    def update(self):
        self.pos.add(self.vel)

class NPC:
    def __init__(self, img_name, pos, clock):
        npc_list.append(self)
        self.clock = clock
        self.image_name = img_name
        self.image = simplegui._load_local_image(('{}/Overworld/NPC/'.format(os.getcwd()))+self.image_name+".png")
        
        self.rows = 1
        self.columns = 4
        
        width = self.image.get_width()
        frame_width = width//self.columns
        height = self.image.get_height()
        frame_height = height//self.rows

        self.pos = pos
        self.frame_center = [frame_width/2, frame_height/2]
        self.frame_dim = [frame_width, frame_height]
        self.frame_index = [0,0]
        
        self.vel = Vector(0,0)
        self.moving = False
        self.scale_factor = 0.26

        self.wall_left = self.pos.x - (self.frame_dim[0]//2*self.scale_factor)
        self.wall_right = self.pos.x + (self.frame_dim[0]//2*self.scale_factor)
        self.wall_top = self.pos.y - (self.frame_dim[1]//2*self.scale_factor)
        self.wall_bot = self.pos.y + (self.frame_dim[1]//2*self.scale_factor)

        self.pokemon_list = []
        with open(('{}/Overworld/NPC/'.format(os.getcwd()))+self.image_name+".txt","r") as file:
            party = file.readlines()
            for pokemonL in party:
                pokemonL = pokemonL.split()
                pokemon = Pokemon(pokemonL[0], int(pokemonL[1]), int(pokemonL[2]), int(pokemonL[3]), [570, 140], [200, 250])
                self.pokemon_list.append(pokemon)
            file.close()
            
    def draw(self, canvas):
        if self.moving == True:
            canvas.draw_image(self.image, 
                    [self.frame_center[0] + self.frame_index[0] * self.frame_dim[0], 
                     self.frame_center[1] + self.frame_index[1] * self.frame_dim[1]], 
                     self.frame_dim, [self.pos.x,self.pos.y], [self.frame_dim[0]*self.scale_factor,self.frame_dim[1]*self.scale_factor])
        else:
            canvas.draw_image(self.image, 
                    [self.frame_center[0] + 0 * self.frame_dim[0], 
                     self.frame_center[1] + self.frame_index[1] * self.frame_dim[1]], 
                     self.frame_dim, [self.pos.x,self.pos.y], [self.frame_dim[0]*self.scale_factor,self.frame_dim[1]*self.scale_factor])
        
        if self.moving:
            self.update()
        self.clock.tick()
        move_on = self.clock.transition(6)
        if move_on == True:
            self.next_frame()

    def next_frame(self):
        self.frame_index[0] += 1
        if self.frame_index[0] >= self.columns:
            self.frame_index[0] = 0

    def update(self):
        self.pos.add(self.vel)

    def collision(self, player):
        player.player_left = player.pos.x - ((player.frame_dim[0]//2)*player.scale_factor)
        player.player_right = player.pos.x + ((player.frame_dim[0]//2)*player.scale_factor)
        player.player_top = player.pos.y - ((player.frame_dim[1]//2)*player.scale_factor)
        player.player_bot = player.pos.y + ((player.frame_dim[1]//2)*player.scale_factor)

        self.wall_left = self.pos.x - (self.frame_dim[0]//2*self.scale_factor)
        self.wall_right = self.pos.x + (self.frame_dim[0]//2*self.scale_factor)
        self.wall_top = self.pos.y - (self.frame_dim[1]//2*self.scale_factor)
        self.wall_bot = self.pos.y + (self.frame_dim[1]//2*self.scale_factor)
        
        col_left = ((self.wall_left - player.player_right) >= 0)
        col_right = ((player.player_left - self.wall_right) >= 0)
        col_top = ((self.wall_top - player.player_bot) >= 0)
        col_bot = ((player.player_top - self.wall_bot) >= 0)

        collision = True
        if (col_right) :
            collision = False
        if (col_left):
            collision = False
        if (col_bot):
            collision = False
        if (col_top):
            collision = False

        return collision

    def interact(self, player):
        self.vel = Vector(0,0)
        self.moving = False
        return True

    def move_to_player(self,player):
        player.player_left = player.pos.x - ((player.frame_dim[0]//2)*player.scale_factor)
        player.player_right = player.pos.x + ((player.frame_dim[0]//2)*player.scale_factor)

        col_left = ((self.wall_left - player.player_right) >= 0)
        col_right = ((player.player_left - self.wall_right) >= 0)
        
        distance = player.pos.y - self.pos.y
        if distance < 96:
            if player.pos.y > self.pos.y:
                if (col_left == False) and (col_right == False):
                    player.vel = Vector(0,0)
                    player.moving = False
                    player.lock = True
                    self.moving = True
                    self.vel = Vector(0,2)

class NPCWall(NPC):
    def __init__(self, img_name, pos, clock):
        super().__init__(img_name, pos, clock)

    def interact(self, player):
        if player.vel.x > 0:
            player.pos.x = self.wall_left-((player.frame_dim[0]//2)*player.scale_factor)-1
        if player.vel.x < 0:
            player.pos.x = self.wall_right+((player.frame_dim[0]//2)*player.scale_factor)+1
        if player.vel.y > 0:
            player.pos.y = self.wall_top-((player.frame_dim[1]//2)*player.scale_factor)-1
        if player.vel.y < 0:
            player.pos.y = self.wall_bot+((player.frame_dim[1]//2)*player.scale_factor)+1
        return False
        
    def move_to_player(self,player):
        pass
    
class Yacht(NPC):
    def __init__(self, img_name, pos, clock):
        super().__init__(img_name, pos, clock)
        self.vel = Vector(0, -0.01)
        self.moving = True

        width = self.image.get_width()
        height = self.image.get_height()
        self.frame_center = [width/2, height/2]
        self.frame_dim = [width, height]
        
    def draw(self, canvas):
        if self.pos.y > -100:
            canvas.draw_image(self.image, 
                    [self.frame_center[0] + 0 * self.frame_dim[0], 
                    self.frame_center[1] + self.frame_index[1] * self.frame_dim[1]], 
                    self.frame_dim, [self.pos.x,self.pos.y], [self.frame_dim[0]*self.scale_factor,self.frame_dim[1]*self.scale_factor])
        if self.moving:
            self.update()
        
        self.clock.tick()
        move_on = self.clock.transition(20)
        if move_on == True:
            self.vel.add(self.vel)
            self.clock.time = 0
            
    def update(self):
        self.pos.add(self.vel)

    def move_to_player(self,player):
        pass

    def interact(self, player):
        return False
        
        


class Wall:
    def __init__(self, name, pos):
        walls_list.append(self)
        self.image = simplegui._load_local_image(('{}/Overworld/Other/'.format(os.getcwd()))+name)
        self.width = self.image.get_width()
        self.height = self.image.get_height()
        self.pos = pos
        self.frame_dim = [self.width, self.height]

        self.wall_left = self.pos.x - (self.frame_dim[0]//2)
        self.wall_right = self.pos.x + (self.frame_dim[0]//2)
        self.wall_top = self.pos.y - (self.frame_dim[1]//2)
        self.wall_bot = self.pos.y + (self.frame_dim[1]//2)


    def draw(self, canvas):
        canvas.draw_image(self.image, 
                    [self.width//2, self.height//2], 
                     [self.width, self.height], [self.pos.x,self.pos.y], [self.frame_dim[0],self.frame_dim[1]])
        
    def collision(self, player):
        player.player_left = player.pos.x - ((player.frame_dim[0]//2)*player.scale_factor)
        player.player_right = player.pos.x + ((player.frame_dim[0]//2)*player.scale_factor)
        player.player_top = player.pos.y
        player.player_bot = player.pos.y + ((player.frame_dim[1]//2)*player.scale_factor)

        col_left = ((self.wall_left - player.player_right) >= 0)
        col_right = ((player.player_left - self.wall_right) >= 0)
        col_top = ((self.wall_top - player.player_bot) >= 0)
        col_bot = ((player.player_top - self.wall_bot) >= 0)

        collision = True
        if (col_right) :
            collision = False
        if (col_left):
            collision = False
        if (col_bot):
            collision = False
        if (col_top):
            collision = False

        return collision

    def interact(self, player):
        if player.vel.x > 0:
            player.pos.x = self.wall_left-((player.frame_dim[0]//2)*player.scale_factor)-1
        if player.vel.x < 0:
            player.pos.x = self.wall_right+((player.frame_dim[0]//2)*player.scale_factor)+1
        if player.vel.y > 0:
            player.pos.y = self.wall_top-((player.frame_dim[1]//2)*player.scale_factor)-1
        if player.vel.y < 0:
            player.pos.y = self.wall_bot+1
        

class Interact(Wall):
    def __init__(self, name, pos, int_type, location = None):
        super().__init__(name, pos)
        self.location = location
        self.int_type = int_type
        
    def interact(self, player):
        if self.int_type == "fight":
            if player.moving:
                player.in_fight = True
        if self.int_type == "interact":
            player.interacting = True
        if self.int_type == "heal":
            for y in player.pokemon_list:
                y.HP = y.fullhp
            
class Background:
    def __init__(self, Map, width, height):
        self.Map = simplegui._load_local_image(('{}/Overworld/map_img/'.format(os.getcwd()))+Map+".png")
        self.map_name = Map
        self.width = width
        self.height = height
        
        self.orig_width = self.Map.get_width()
        self.orig_height = self.Map.get_height()

    def draw(self, canvas):
        canvas.draw_image(self.Map, (self.orig_width/2,self.orig_height/2), (self.orig_width,self.orig_height), (self.width/2, self.height/2), (self.width,self.height))

    def load_wall(self):
        global walls_list, npc_list, npc_lost
        walls_list = []
        npc_list = []
        with open(('{}/Overworld/map_txt/'.format(os.getcwd()))+self.map_name+".txt","r") as file:
            level = file.readlines()
            x = y = 0
            for row in level:
                for col in row:
                    if col == "t":
                        wall = Wall("tree.png", Vector(8+(32*x), 0+(32*y)))
                    if col == "w":
                        wall = Wall("up.png", Vector(8+(32*x), 8+(32*y)))
                    if col == "s":
                        wall = Wall("up.png", Vector(8+(32*x), -8+(32*y)))
                    if col == "a":
                        wall = Wall("left.png", Vector(16+(32*x), 0+(32*y)))
                    if col == "d":
                        wall = Wall("left.png", Vector(0+(32*x), 0+(32*y)))
                    if col == "1":
                        wall = Interact("tree.png", Vector(8+(32*x), 0+(32*y)), "interact", 0)
                    if col == "2":
                        if (self.map_name == "bossfight1") and ("boss3" not in npc_lost):
                            wall = Wall("tree.png", Vector(8+(32*x), 0+(32*y)))
                        elif (self.map_name == "bossfight2") and ("boss4" not in npc_lost):
                            wall = Wall("tree.png", Vector(8+(32*x), 0+(32*y)))
                        else:
                            wall = Interact("tree.png", Vector(8+(32*x), 0+(32*y)), "interact", 1)
                    if col == "3":
                        wall = Interact("tree.png", Vector(8+(32*x), 0+(32*y)), "interact", 2)
                    if col == "4":
                        wall = Interact("tree.png", Vector(8+(32*x), 0+(32*y)), "interact", 3)
                    if col == "f":
                        wall = Interact("tree.png", Vector(8+(32*x), 0+(32*y)), "fight")
                    if col == "h":
                        wall = Interact("tree.png", Vector(8+(32*x), 0+(32*y)), "heal")
                    if col == "y":
                        clock = Clock()
                        yacht = Yacht("yacht", Vector(8+(32*x), 0+(32*y)), clock)
                    if col == "b":
                        clock = Clock()
                        npc_name = self.load_npc()
                        if npc_name in npc_lost:
                            npc = NPCWall(npc_name, Vector(8+(32*x), 0+(32*y)), clock)
                        else:
                            npc = NPC(npc_name, Vector(8+(32*x), 0+(32*y)), clock)
                    x += 1
                y += 1
                x = 0
            file.close()
            
    def new_level(self, location, player):
        map_str = {"map2y": [["route1", Vector(111,43)]],
                   "map": [["route1", Vector(770,338)], ["route2", Vector(58,236)], ["pokecenter", Vector(406,424)]],
                   "map2": [["route1", Vector(111,43)]],
                   "map3": [["route3", Vector(745,47)]],
                   "route1": [["map2", Vector(756, 169)], ["map", Vector(58,169)]],
                   "route2": [["map", Vector(768,225)], ["route3a", Vector(56,120)], ["route3b", Vector(47,447)]],
                   "route3": [["route2a", Vector(680,143)], ["route2b", Vector(514,443)], ["map3", Vector(220, 424)], ["route4", Vector(52,319)]],
                   "route4": [["route3", Vector(774,351)], ["bossfight1",Vector(406,424)]],
                   "map3": [["route3",Vector(746,67)], ["gym2",Vector(406,424)], ["pokecenter2",Vector(406,424)]],
                   "gym2": [["map3",Vector(650,143)]],
                   "pokecenter": [["map",Vector(290,261)]],
                   "pokecenter2": [["map3",Vector(172,382)]],
                   "bossfight1": [["route4",Vector(626,200)], ["bossfight2",Vector(406,424)]],
                   "bossfight2": [["bossfight1",Vector(406,70)], ["bossfight3",Vector(406,424)]],
                   "bossfight3": [["bossfight2",Vector(406,70)]]}
        
        player.pos = map_str[self.map_name][location][1]
        player.vel = Vector(0,0)
        self.map_name = map_str[self.map_name][location][0]

        if (self.map_name == "route3a") or (self.map_name == "route3b"):
            self.map_name = "route3"
        if (self.map_name == "route2a") or (self.map_name == "route2b"):
            self.map_name = "route2"

        player.interacting = False
        self.Map = simplegui._load_local_image(('{}/Overworld/map_img/'.format(os.getcwd()))+self.map_name+".png")
        self.load_wall()

    def load_npc(self):
        npc_str =  {"gym2": "boss1",
                    "bossfight3": "boss2",
                    "bossfight1": "boss3",
                    "bossfight2": "boss4"}
        npc_name = npc_str[self.map_name]
        return npc_name

    def load_pokelvl(self):
        wildpoke = {"map2y": [1,5],
                   "map": [6,10],
                   "map2": [1,5],
                   "map3": [11,15],
                   "route1":[1,5],
                   "route2": [6,10],
                   "route3": [11,15],
                   "route4": [16,21]}
        pokerange = wildpoke[self.map_name]
        return pokerange

class Pokedex:
    def __init__(self, kbd):
        self.player_pokedex = []
        self.pokedex = []
        self.kbd = kbd
        self.centre = [0,0]
        self.first = True
        self.poke_list =[]
        self.index = 0
        self.bag = simplegui._load_local_image('{}/Fight/Other/bag.png'.format(os.getcwd()))
        self.light = simplegui._load_local_image('{}/Fight/Other/highlight.png'.format(os.getcwd()))
        self.pos = [[(348,145),(348,265),(348,380)],[(598,145),(598,265),(598,380)]]

    def draw(self, canvas):
        self.player_pokedex = []
        self.pokedex = []
        with open('{}/Fight/PlayerPokedex.txt'.format(os.getcwd()),"r") as file:
            all_lines = file.readlines()
            for pokemon_line in all_lines:
                pokemon = pokemon_line.split()
                self.player_pokedex.append(pokemon[0])
            file.close()
        
        count = 0
        with open('{}/Fight/Pokedex.txt'.format(os.getcwd()),"r") as file:
            all_lines = file.readlines()
            temp_list = []
            for pokemon_line in all_lines:
                pokemon = pokemon_line.split()
                count += 1
                if pokemon[0] in self.player_pokedex:
                    temp_list.append(str(count)+"    "+pokemon[0])
                else:
                    temp_list.append(str(count)+"    ?????")
                if len(temp_list) >= 6:
                    self.pokedex.append(temp_list)
                    temp_list = []
            if len(temp_list) != 0:
                self.pokedex.append(temp_list)
                temp_list = []
                
        self.poke_list = self.pokedex[self.index]
        canvas.draw_image(self.bag, (375,250), (750,500), (400,240), (735,490))
        if not self.first:
            if self.kbd.left and self.centre[0] == 1:
                self.centre[0] = 0
                self.first = True
            elif self.kbd.down and self.centre[1] < 2:
                self.centre[1] += 1
                self.first = True
            elif self.kbd.down and self.centre[1] == 2:
                if not (self.index == len(self.pokedex)-1):
                    self.index += 1
                self.first = True
            elif self.kbd.up and self.centre[1] == 0:
                if not (self.index == 0):
                    self.index -= 1
                self.first = True
            elif self.kbd.right and self.centre[0] == 0:
                self.centre[0] = 1
                self.first = True
            elif self.kbd.up and self.centre[1] > 0:
                self.centre[1] -= 1
                self.first = True
        else:
            if not(self.kbd.left or self.kbd.right or self.kbd.up or self.kbd.down):
                self.first = False
        canvas.draw_image(self.light, (116,45), (233,91), self.pos[self.centre[0]][self.centre[1]], (233,91))
        for i in range(0,len(self.poke_list)):
            if i<3:
                canvas.draw_text(self.poke_list[i], (290, 150+(i*120)), 25, 'Black')
            else:
                canvas.draw_text(self.poke_list[i], (540, 150+(i-3)*120), 25, 'Black')
        
class Interaction:
    def __init__(self, player, keyboard):
        self.player = player
        self.keyboard = keyboard

    def update(self):
        if self.keyboard.start:
            if self.player.lock == False:
                if self.keyboard.right:
                    self.player.vel = Vector(2, 0)
                    self.player.frame_index[1] = 2
                    self.player.moving = True
                elif self.keyboard.left:
                    self.player.vel = Vector(-2,0)
                    self.player.frame_index[1] = 1
                    self.player.moving = True
                elif self.keyboard.up:
                    self.player.vel = Vector(0,-2)
                    self.player.frame_index[1] = 3
                    self.player.moving = True
                elif self.keyboard.down:
                    self.player.vel = Vector(0,2)
                    self.player.frame_index[1] = 0
                    self.player.moving = True
                else:
                    self.player.moving = False
                    self.player.vel = Vector(0,0)                
class Game:
    def __init__(self, welcome, tutorial, player, keyboard, background):
        self.player = player
        self.keyboard = keyboard
        self.inter = Interaction(self.player, self.keyboard)
        self.welcome = welcome
        self.tutorial = tutorial
        self.background = background
        self.Kbd = Kbd()
        self.pokedex = Pokedex(self.Kbd)
        pokemon2 = Pokemon('Palkia', 19, 5, 50, [210, 250], [570, 140])
        self.fight = Fight([pokemon2], [pokemon2], self.Kbd, False)
        self.fightB = False

    def draw(self, canvas):
        global walls_list, npc_list, npc_lost
        
        if self.keyboard.start:
            if self.fightB:
                frame.set_keydown_handler(self.Kbd.keyDown)
                frame.set_keyup_handler(self.Kbd.keyUp)
                self.fight.draw(canvas)
                if self.fight.end == True:
                    self.Kbd.KeyReset()
                    frame.set_keydown_handler(self.keyboard.keyDown)
                    frame.set_keyup_handler(self.keyboard.keyUp)
                    self.keyboard.KeyReset()
                    if self.fight.npc:
                        if (self.fight.catch == False) and (self.fight.run == False) and (self.fight.lost == False):
                            npc_lost.append(npc_list[0].image_name)
                        else:
                            self.player.pos.x +=50
                            self.player.pos.y +=50
                        self.player.lock = False
                        self.background = Background(self.background.map_name, WIDTH, HEIGHT)
                        self.background.load_wall()
                    if self.fight.lost:
                        self.player.lives -= 1
                        for pokemon in player.pokemon_list:
                            pokemon.HP = pokemon.fullhp
                    self.fightB = False
            elif self.keyboard.pokedex:
                frame.set_keydown_handler(self.Kbd.keyDown)
                frame.set_keyup_handler(self.Kbd.keyUp)
                self.pokedex.draw(canvas)
                if self.Kbd.quit:
                    self.Kbd.KeyReset()
                    frame.set_keydown_handler(self.keyboard.keyDown)
                    frame.set_keyup_handler(self.keyboard.keyUp)
                    self.keyboard.KeyReset()
                    self.keyboard.pokedex = False
                    self.Kbd.quit = False
            else:
                self.inter.update()
                self.player.update()
                self.background.draw(canvas)
                
                for x in walls_list:
                    x.draw(canvas)
                    col = x.collision(self.player)
                    if col == True:
                        x.interact(self.player)
                        if player.interacting == True:
                            self.background.new_level(x.location, self.player)
        
                        if player.in_fight == True:
                            rand_int = random.random()
                            if rand_int < 0.007:
                                pokerange = self.background.load_pokelvl()
                                pokelvl = random.randint(pokerange[0], pokerange[1])
                                num_lines = sum(1 for line in open(('{}/Overworld/map_poke/'.format(os.getcwd()))+self.background.map_name+".txt"))
                                poke_num = random.randint(1,num_lines)
                                with open(('{}/Overworld/map_poke/'.format(os.getcwd()))+self.background.map_name+".txt","r") as file:
                                    area = file.readlines()
                                    count = 1
                                    for pokemon in area:
                                        pokemon = pokemon.split()
                                        if count == poke_num:
                                            pokeName = pokemon[0]
                                        count += 1
                                    file.close()
                                Wpokemon = Pokemon(pokeName, -1, pokelvl, 0, [570, 140], [200, 250])
                                self.fight = Fight([Wpokemon], self.player.pokemon_list, self.Kbd, False)
                                self.fightB = True
                                print("fight")
                            player.in_fight = False
                            
                 for y in npc_list:
                    y.draw(canvas)
                    y.move_to_player(self.player)
                    col = y.collision(self.player)
                    if col == True:
                        self.fightB = y.interact(self.player)
                        if self.fightB == True:
                            self.fight = Fight(npc_list[0].pokemon_list, self.player.pokemon_list, self.Kbd, True)
                
                if self.player.lives == 0:
                    self.player.lives = 6
                    self.keyboard.start = False
                    self.background = Background("map2y", WIDTH, HEIGHT)
                    self.background.load_wall()
                    self.player.pos = Vector(552, 224)

                #self.background.draw(canvas)
               self.player.draw(canvas)
            
        else:
            if not self.keyboard.tutorial:
                self.welcome.draw(canvas)    
            else:
                self.tutorial.draw(canvas)
                if self.keyboard.back:
                    self.keyboard.tutorial = False
                    self.keyboard.back = False
              
kbd = Keyboard()
clock = Clock()
player = Player(clock)
welcome = Welcome("welcome.png")
tutorial = Welcome("tutorial.png")
background = Background("bossfight1", WIDTH, HEIGHT)
background.load_wall()
game = Game(welcome, tutorial, player, kbd, background)


frame = simplegui.create_frame('Pokemon', WIDTH, HEIGHT)
frame.set_canvas_background('Black')
frame.set_draw_handler(game.draw)
frame.set_keydown_handler(kbd.keyDown)
frame.set_keyup_handler(kbd.keyUp)
frame.start()
